package javapoe.part1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {
    String validRecipient = "+27718693002";
    String invalidRecipient = "08575975889";
    String validMessage = "Hi Mike, can you join us for dinner tonight?";

    @Test public void testRecipientSuccess() {
        Message m = new Message(0, validRecipient, validMessage);
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }
    @Test public void testRecipientFailure() {
        Message m = new Message(1, invalidRecipient, "Hi Keegan, did you receive the payment?");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", m.checkRecipientCell());
    }
    @Test public void testMessageLengthSuccess() {
        Message m = new Message(0, validRecipient, validMessage);
        assertEquals("Message ready to send.", m.checkMessageLength());
    }
    @Test public void testMessageLengthFailure() {
        String longMsg = new String(new char[260]).replace('\0', 'a');
        Message m = new Message(0, validRecipient, longMsg);
        assertEquals("Message exceeds 250 characters by 10, please reduce the size.", m.checkMessageLength());
    }
    @Test public void testMessageHash() {
        Message m = new Message(0, validRecipient, validMessage);
        m.getMessageID("0012345678");
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }
    @Test public void testMessageIDGenerated() {
        Message m = new Message(0, validRecipient, validMessage);
        assertNotNull(m.getMessageID());
        assertEquals(10, m.getMessageID().length());
    }
    @Test public void testMessageSentOptions() {
        Message m = new Message(0, validRecipient, validMessage);
        assertEquals("Message successfully sent.", m.SentMessage(1));
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }
}
