package javapoe.part1;

import java.util.Scanner;

public class QuickChat {
    public static  void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("---QuickChat Started---\n");
        
        boolean running = true;
        
        while(running)
        {
            System.out.println("\nNumeric Menu: ");
            System.out.println("1)Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("Choose an option: ");
            
            String choiceStr = scanner.nextLine();
            int choice;
            try
            {
               choice = Integer.parseInt(choiceStr);
            }
            catch (NumberFormatException e)
            {
                System.out.println("Please enter a valid number.");
                continue;
            }
            switch (choice)
            {
                case 1:
                    handleSendingMessages(scanner);
                    break;
                case 2:
                    System.out.println("Coming Soon");
                    break;
                case 3:
                    System.out.println("Existing QuickChat. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option, Try again.");
            }
        }
        scanner.close();
    }   
    private static void handleSendingMessages(Scanner scanner)
    {
        System.out.println("How many messages do you want to enter?");
        int numMessages;
        try
        {
            numMessages = Integer.parseInt(scanner.nextLine());
        }
        catch (NumberFormatException e)
        {
            System.out.println("Invalid number");
            return;
        }
        for (int i=1; i <= numMessages; i++)
        {
            System.out.println("\n---- Message " + i + " of " + numMessages + "---");
            
            String recipient = "";
            boolean validRecipient = false;
            while (!validRecipient)
            {
                System.out.println("Enter recipient cell number (max 10 chars ,include code): ");
                recipient = scanner.nextLine();
                
                Message temp =new Message (i, recipient , "temp"); 
                String validationMsg = temp.checkRecipientCell();
                System.out.println(validationMsg);
                if (validationMsg.contains("successfully"))
                {
                    validRecipient = true;
                }
            }
            // Validate Message Length
            String messageText = "";
            boolean validMessage = false;
            while (!validMessage)
            {
                 System.out.println("Enter your message (max 250 chars): ");
                 messageText = scanner.nextLine();
                 
                 if (messageText.length() >250)
                 {
                     int excess = messageText.length() - 250;
                     System.out.println("Message exceeds 250 characters by "+ excess + ";please reduce the number of words.");            
                 }
                 else
                 {
                     System.out.println("Message ready to send");
                     validMessage = true;
                 }
            }
            //Create message object
            Message newMessage = new Message (i ,recipient , messageText);
            
            System.out.println("\nChoose action for this message: ");
            System.out.println("1) Send messgae");
            System.out.println("2) Disregard message");
            System.out.println("3) Store message to send later");
            System.out.println("Choice: ");
            
            int actionChoice;
            try
            {
                actionChoice = Integer.parseInt(scanner.nextLine());
            }
            catch (NumberFormatException e)
            {
                actionChoice = 2;
            }
            String actionResult = newMessage.SentMessage(actionChoice);
            System.out.println(actionResult);
            
            //if sent display details
            if (actionChoice ==1)
            {
            System.out.println("\n=====Message Details=====");
            System.out.println("Message ID: " + newMessage.getMessageID());
            System.out.println("Message Hash: " + newMessage.createMessageHash());
            System.out.println("Recipient: " + newMessage.getRecipient());
            System.out.println("Message: " + newMessage.getMessageText());           
        }
        else if(actionChoice ==3)
                {
                
                }
    
        }
        System.out.println("\nTotal messages sent this session: " + Message.returnTotalMessages());
  }
}